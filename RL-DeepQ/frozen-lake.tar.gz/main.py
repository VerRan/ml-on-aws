import os
from pathlib import Path

import fire
import numpy as np
import torch

from frozen_lake import DeepQConfig, train


def main(**kwargs) -> None:
    """Train the policy network."""
    config = DeepQConfig(**kwargs)
    policy_net, rewards = train(config)
    model_dir = Path(os.environ.get('SM_MODEL_DIR', './'))
    with open(model_dir / 'policy.pth', 'wb') as f:
        torch.save(policy_net.state_dict(), f)
    np.savez_compressed(model_dir / 'reward.npz', rewards)


if __name__ == '__main__':
    fire.Fire(main)
