from setuptools import setup

setup(
    name='frozen-lake',
    version='0.1.0',
    packages=['frozen_lake'],
    install_requires=[
        'dataclasses',
        'fire',
        'gym',
        'torch',
    ],
)
