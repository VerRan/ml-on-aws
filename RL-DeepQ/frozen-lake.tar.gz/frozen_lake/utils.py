import numpy as np


def moving_average(x: np.ndarray, n: int = 100) -> np.ndarray:
    summed = x.cumsum()
    summed[n:] = summed[n:] - summed[:-n]
    return summed[n - 1:] / n
