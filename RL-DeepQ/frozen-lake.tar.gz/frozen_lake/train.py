import copy
from typing import Tuple

import numpy as np
import torch
import torch.nn.functional as F
import torch.optim as optim

from .config import DeepQConfig
from .environment import LeveledFrozenLake
from .model import DeepQNetwork
from .memory import Transition, ReplayMemory
from .state import get_state


def update_step(
        policy_net: DeepQNetwork, target_net: DeepQNetwork,
        optimizer: torch.optim.Optimizer, memory: ReplayMemory, config: DeepQConfig
) -> None:
    """Get a random batch cyclic memory and update weights."""
    transitions = memory.sample(config.batch_size)
    batch = Transition(*zip(*transitions))

    non_final_mask = torch.tensor(
        tuple(map(lambda s: s is not None, batch.next_state)),
        dtype=torch.bool,
    )
    non_final_next_states = torch.stack([s for s in batch.next_state if s is not None])

    state_batch = torch.stack(batch.state)
    action_batch = torch.tensor(batch.action)
    reward_batch = torch.tensor(batch.reward)

    state_action_values = policy_net(state_batch).gather(1, action_batch[:, None])
    next_state_values = torch.zeros(config.batch_size)
    next_state_values[non_final_mask] = target_net(
        non_final_next_states
    ).max(1)[0].detach()
    expected_state_action_values = (next_state_values * config.gamma) + reward_batch

    loss = F.smooth_l1_loss(
        state_action_values, expected_state_action_values.unsqueeze(1)
    )

    optimizer.zero_grad()
    loss.backward(retain_graph=True)
    for param in policy_net.parameters():
        param.grad.data.clamp_(-1, 1)
    optimizer.step()


def train(config: DeepQConfig) -> Tuple[DeepQNetwork, np.ndarray, np.ndarray]:
    """Train a policy network."""
    np.random.seed(config.seed)
    torch.manual_seed(config.seed)
    # Setup the networks
    policy_net = DeepQNetwork(config.n_state_features, config.n_actions)
    target_net = DeepQNetwork(config.n_state_features, config.n_actions)
    target_net.load_state_dict(policy_net.state_dict())
    target_net.eval()
    optimizer = optim.RMSprop(policy_net.parameters())
    memory = ReplayMemory(config.memory_size)

    # Monitoring
    rewards = np.zeros(config.n_episodes)
    best_net = None
    max_reward = 0.0

    for episode in range(config.n_episodes):
        env = LeveledFrozenLake.random(config.p_mistake_draw)
        env.reset()
        env.seed(config.seed + episode)
        state = get_state(env)
        for _ in range(config.max_steps_per_episode):
            if np.random.uniform() < config.epsilon(episode):
                action = np.random.randint(env.nA)
            else:
                action = policy_net(state).argmax().item()
            _, reward, done, _ = env.step(action)
            next_state = get_state(env)
            if done:
                memory.push(state, action, None, reward)
                break
            memory.push(state, action, next_state, reward)
            state = next_state
        rewards[episode] = reward
        if episode >= config.start_saving_policy:
            reward_moving_avg = rewards[episode-100:episode].mean()
            if reward_moving_avg > max_reward:
                max_reward = reward_moving_avg
                best_net = copy.deepcopy(policy_net)
        if episode and episode % config.target_update == 0:
            target_net.load_state_dict(policy_net.state_dict())
        if len(memory) >= config.batch_size:
            update_step(policy_net, target_net, optimizer, memory, config)
    assert best_net is not None, "No improvement to policy found"
    print(f"MaxReward={max_reward}")
    return best_net or policy_net, rewards
