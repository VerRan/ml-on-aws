import numpy as np
import torch
from gym.envs.toy_text import FrozenLakeEnv

ONE_HOT = np.eye(4)


def get_state(env: FrozenLakeEnv) -> torch.Tensor:
    board = 1. * (env.desc.ravel() == b'H')[1:-1]
    row = env.s // env.ncol
    col = env.s % env.ncol
    np_state = np.concatenate([
        board,
        ONE_HOT[row],
        ONE_HOT[col],
    ])
    return torch.from_numpy(np_state.astype('float32'))
