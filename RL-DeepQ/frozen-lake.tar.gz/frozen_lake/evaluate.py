from typing import Callable

from gym.envs.toy_text import FrozenLakeEnv


def play_level(env: FrozenLakeEnv, get_action: Callable[[FrozenLakeEnv], int]) -> float:
    """Play a FrozenLake level -- can be manual or with an agent."""
    env.reset()
    for i in range(100):
        env.seed(i)
        action = get_action(env)
        _, reward, done, _ = env.step(action)
        if done:
            return reward
    return reward


def play_manually(env: FrozenLakeEnv) -> None:
    from ipywidgets import Button, HBox, VBox
    from IPython.display import clear_output, display

    key_map = {
        'LEFT': 0,
        'DOWN': 1,
        'RIGHT': 2,
        'UP': 3
    }

    disabled = Button(disabled=True)
    up = Button(description='UP')
    upper = HBox([disabled, up, disabled])
    lower = HBox([
        Button(description=key)
        for key in ['LEFT', 'DOWN', 'RIGHT']
    ])
    arrows = VBox([upper, lower])

    def step(output):
        done = env.step(
            key_map[output.description]
        )[2]
        clear_output()
        env.render()
        display(arrows)
        if done:
            print('-- Win --' if env.s == 15 else '-- Lose --')

    up.on_click(step)
    for button in lower.children:
        button.on_click(step)

    env.reset()
    env.render()
    display(arrows)
