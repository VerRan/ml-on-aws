from collections import namedtuple

import numpy as np


Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))

class ReplayMemory:
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []
        self.position = 0

    def push(self, *args):
        """Saves a transition."""
        if len(self.memory) < self.capacity:
            self.memory.append(None)
        self.memory[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        indices = np.random.choice(
            np.arange(len(self.memory)),
            size=batch_size,
            replace=False,
        )
        return [self.memory[index] for index in indices]

    def __len__(self):
        return len(self.memory)
