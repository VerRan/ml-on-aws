import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from gym.envs.toy_text.frozen_lake import FrozenLakeEnv

from .state import get_state


class DeepQNetwork(nn.Module):
    """Trainable policy network."""
    def __init__(self, n_features: int, n_actions: int) -> None:
        super().__init__()
        self.linear1 = nn.Linear(n_features, 16)
        self.linear2 = nn.Linear(16, n_actions)

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.linear1(state))
        return F.softmax(self.linear2(x), -1)

    def learned_action(self, env: FrozenLakeEnv) -> int:
        state = get_state(env)
        softmax = self.forward(state).detach().numpy()
        return (softmax.cumsum() > np.random.uniform()).argmax()
