import math
from dataclasses import dataclass
from typing import Optional

import numpy as np


@dataclass
class DeepQConfig:
    """Hyperparameters"""
    # Learning
    gamma: float = 0.999
    target_update: int = 10
    batch_size: int = 128
    n_episodes: int = 2000
    max_steps_per_episode: int = 100
    memory_size: int = 10000
    start_saving_policy: int = 1000

    # Random action threshold
    epsilon_start: float = 0.5
    epsilon_end: float = 0.05
    epsilon_decay: float = 200.0

    # Environment
    n_state_features: int = 22
    n_actions: int = 4

    # Leveling
    min_p_mistake: float = 0.0
    max_p_mistake: float = 0.4

    # Seed
    seed: Optional[int] = 123

    def epsilon(self, step: int) -> float:
        """Compute the random action threshold."""
        return (
            self.epsilon_end +
            (self.epsilon_start - self.epsilon_end) *
            math.exp(-1. * step / self.epsilon_decay)
        )

    @property
    def p_mistake_draw(self):
        """Draw a random p_mistake"""
        return np.random.uniform(self.min_p_mistake, self.max_p_mistake)
