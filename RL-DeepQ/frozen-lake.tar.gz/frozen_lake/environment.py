from typing import Optional

import numpy as np

from gym.envs.toy_text.frozen_lake import FrozenLakeEnv, generate_random_map

LEFT = 0
DOWN = 1
RIGHT = 2
UP = 3


class Level:
    def __init__(self, board: np.ndarray, p_mistake: float) -> None:
        self.board = board
        self.p_mistake = p_mistake

    @classmethod
    def random(cls, p_mistake: float) -> 'Level':
        """Given p_mistake, create a new random level."""
        board = generate_random_map(size=4)
        return cls(board, p_mistake)


class LeveledFrozenLake(FrozenLakeEnv):
    def __init__(self, level: Level) -> None:
        super().__init__(desc=level.board)
        action_prob = 1 - level.p_mistake

        def to_s(row, col):
            return row * self.ncol + col

        def inc(row, col, a):
            if a == LEFT:
                col = max(col-1,0)
            elif a == DOWN:
                row = min(row+1,self.nrow-1)
            elif a == RIGHT:
                col = min(col+1,self.ncol-1)
            elif a == UP:
                row = max(row-1,0)
            return (row, col)

        def transition(row, col, action, prob):
            newrow, newcol = inc(row, col, action)
            newstate = to_s(newrow, newcol)
            newletter = self.desc[newrow, newcol]
            done = bytes(newletter) in b'GH'
            reward = float(newletter == b'G')
            return (prob, newstate, reward, done)

        for row in range(self.nrow):
            for col in range(self.ncol):
                state = to_s(row, col)
                for action in range(4):
                    transitions = []
                    letter = self.desc[row, col]
                    if letter in b'GH':
                        transitions.append((1.0, state, 0, True))
                    else:
                        transitions.append(transition(row, col, action, action_prob))
                        mistake_prob = level.p_mistake / 2
                        for mistake in [(action-1)%4, (action+1)%4]:
                            transitions.append(
                                transition(row, col, mistake, mistake_prob)
                            )
                    self.P[state][action] = transitions

    @classmethod
    def random(cls, p_mistake: float) -> 'LeveledFrozenLake':
        level = Level.random(p_mistake)
        return cls(level)


def get_test_level() -> LeveledFrozenLake:
    level = Level(
        board=FrozenLakeEnv().desc,
        p_mistake=0.2,
    )
    return LeveledFrozenLake(level)
